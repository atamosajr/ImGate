//
//  ImGateStaff.h
//  ImGateStaff
//
//  Created by Kang Byeonghak on 09/05/2019.
//  Copyright © 2019 ImGATE, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ImGateStaff.
FOUNDATION_EXPORT double ImGateStaffVersionNumber;

//! Project version string for ImGateStaff.
FOUNDATION_EXPORT const unsigned char ImGateStaffVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ImGateStaff/PublicHeader.h>
