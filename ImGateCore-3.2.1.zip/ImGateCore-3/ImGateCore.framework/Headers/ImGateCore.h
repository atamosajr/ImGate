//
//  ImGateCore.h
//  ImGateCore
//
//  Created by Kang Byeonghak on 23/04/2019.
//  Copyright © 2019 ImGATE, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ImGateCore.
FOUNDATION_EXPORT double ImGateCoreVersionNumber;

//! Project version string for ImGateCore.
FOUNDATION_EXPORT const unsigned char ImGateCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ImGateCore/PublicHeader.h>
